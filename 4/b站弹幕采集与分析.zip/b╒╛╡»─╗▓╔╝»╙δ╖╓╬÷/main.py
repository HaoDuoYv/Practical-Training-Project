import analyse,get_info,word_Cloud
if __name__ =='__main__':
    get_info.get_info()
    word_Cloud.word_cloud()
    analyse.yonghu_danmu()
    analyse.shijian_danmu()
    analyse.week_danmu()
    analyse.day_danmu()
    analyse.time_danmu()
    analyse.time_danmu()

