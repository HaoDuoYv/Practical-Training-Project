from datetime import datetime
import matplotlib.pyplot as plt
import pandas as pd
from clyent import color
from sympy import floor

comment = pd.read_csv('./data/data.csv')
comment['发送时间'] = comment['发送时间'].apply(lambda x: datetime.fromtimestamp(x).strftime('%Y-%m-%d %H:%M:%S'))
comment['发送时间'] = pd.to_datetime(comment['发送时间'])
plt.rcParams['font.sans-serif'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False
#用户评论次数趋势
def yonghu_danmu():

    num=comment['用户Id'].value_counts().value_counts()
    num2=num[:6]
    num2['七次及以上']=sum(num[6:])
    #绘制
    plt.figure(figsize=(8,6))

    plt.style.use('ggplot')

    plt.bar(num2.index.astype(str),num2.values,color='g',width=0.8)
    plt.xlabel('单个用户弹幕发送次数')
    plt.ylabel('用户数量')
    plt.title('用户评论次数分布')
    plt.savefig('./统计分析图/用户评论次数分布.jpg')
    print('用户评论次数分布条形图已保存')
    #plt.show()
#用户评论时间分布
def shijian_danmu():


    num_date=comment['发送时间'].dt.date.value_counts().sort_index()
    #print(num_date)
    plt.figure(figsize=(16,9))


    plt.plot(num_date.index.astype(str),num_date.values)
    #plt.xlim(num_date.index.astype(str)[0],num_date.index.astype(str)[-1])
    plt.xticks(range(1,len(num_date.index.astype(str)),30),rotation=45)
    # 添加网格和标签
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.title('评论数量时间趋势', fontsize=16)
    plt.xlabel('日期', fontsize=14)
    plt.ylabel('评论数量', fontsize=14)

    # 自动旋转x轴标签并调整布局
    plt.savefig('./统计分析图/评论数量时间趋势.jpg')
    print('评论数量时间趋势折线图已保存')
    #plt.show()

#弹幕与周几
def week_danmu():


    num=comment['发送时间'].dt.dayofweek.value_counts().sort_index()
    num=num.rename({0:'周一',1:'周二',2:'周三',3:'周四',4:'周五',5:'周六',6:'周日'})
    #print(num)
    plt.figure(figsize=(8,6))

    plt.plot(num.index,num.values)
    plt.xlabel('周')
    plt.ylabel('弹幕数量')
    plt.title('弹幕与星期的分布图')
    plt.savefig('./统计分析图/弹幕与星期的分布图.jpg')
    print('弹幕与星期的分布折线图已保存')
    #plt.show()
#弹幕数量随天的分布图
def day_danmu():


    time_counts = comment['发送时间'].dt.hour.value_counts().sort_index()

    plt.figure(figsize=(8,6))

    plt.plot(time_counts.index, time_counts.values, marker='o', color='r', label='弹幕数量')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.xticks(range(0,24))
    plt.xlabel('时间')
    plt.ylabel('弹幕数量')
    plt.title('弹幕分布数量天内分布')
    plt.savefig('./统计分析图/弹幕分布数量天内分布.jpg')
    print('弹幕分布数量天内分布折线图已保存')
    #plt.show()
    #print( time_counts)

#弹幕随时长分布直方图，找到高潮部分
def time_danmu():
    num = comment['出现时间']  # 原始数据是秒
    plt.figure(figsize=(9, 5))
    bins = range(int(min(num)), int(max(num)) + 1)

    # 绘制直方图并获取频数数据
    n= plt.hist(num, bins=bins, edgecolor='blue')
    plt.axhline(y=13, color='r', linestyle='--', linewidth=1)
    sel=n[0]
    h=n[1]
    plt.xlabel('分钟刻度')
    plt.ylabel('弹幕数量')
    plt.title('弹幕随时长分布')
    plt.savefig('统计分析图/弹幕随时长分布直方图.jpg')
    print('弹幕随时长分布直方图已保存')
    start_sec=0
    end_sec=0
    k=1
    # 找出弹幕量大于15的时间区间（秒）
    high_activity_intervals = []
    for i in range(len(sel)):
        if sel[i] > 13:
            # 当前区间的时间范围（秒）
            start_sec = h[i]
            k=0
        elif k!=1 and sel[i]<=13:
            end_sec = h[i + 1]
            high_activity_intervals.append((start_sec, end_sec))
            k=1


    # 打印超过高潮线的时间区间
    with open('统计分析图/影片高潮.txt','w',encoding='utf-8') as fp:
        if high_activity_intervals:
            fp.write("弹幕量超过15的高潮时间段（时:分:秒）：\n")
            for start_sec, end_sec in high_activity_intervals:
                start_time = format_time(start_sec)
                end_time = format_time(end_sec)
                fp.write(f"{start_time} - {end_time}\n")
        else:
            fp.write("没有弹幕量超过15的时间段")
        fp.close()
# 将秒转换为时分秒格式的函数
def format_time(seconds):
    # 计算小时、分钟和剩余秒数
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{int(hours)}:{int(minutes):02d}:{int(secs):02d}"#02d进行补0效果

time_danmu()