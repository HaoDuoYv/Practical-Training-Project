import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
def get_info():
    cid=123756195
    damu_url=f'https://comment.bilibili.com/{cid}.xml'
    headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 Edg/137.0.0.0'
#                 Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 Edg/137.0.0.0
    }

    rq=requests.get(damu_url,headers=headers)

    rq.encoding='utf-8'
    soup=BeautifulSoup(rq.text,'xml')
    temp=soup.select('d')
    comment=[i.text for i in temp]
    attribute=[i.get('p').split(',') for i in temp]
    coumns=['出现时间','模式','字体大小','颜色代码','发送时间','弹幕池','用户Id','rowid','gourpid']
    data=pd.DataFrame(attribute,columns=coumns)
    data['comment']=comment
    data.dropna(inplace=True)
    data['comment'] = data['comment'].str.strip().str.replace('\n', '')
    data.to_csv('./data/data.csv',encoding='utf-8-sig',index=None)
    print('弹幕采集成功')