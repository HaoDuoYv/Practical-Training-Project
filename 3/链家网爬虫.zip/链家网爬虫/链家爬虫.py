from selenium import webdriver
from lxml import etree
import pandas as pd
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
import time
import random
import re
from selenium.common.exceptions import NoSuchElementException, TimeoutException


# 总页面数
def page_num(docs):
    try:
        num = docs.xpath('//*[@id="content"]/div[1]/ul[2]/li[last()-1]/a/text()')[0]
        return int(num)
    except:
        # 备用方案：从URL获取页码
        num = docs.xpath('//*[@id="content"]/div[1]/ul[2]/li[last()-1]/a/@href')
        if num:
            return int(num[0].split('/')[2].strip('pg'))
        return 1  # 默认只有1页


# 租房区域
def quyu_info(docs):
    quyus = []
    items = docs.xpath('//div[@class="content__list--item"]')
    for item in items:
        quyu = item.xpath('.//p[@class="content__list--item--des"]/a[1]/text()')
        quyus.append(quyu[0] if quyu else "暂无区域")
    return quyus


# 小区名 - 重新编写
def name_info(docs):
    names = []
    items = docs.xpath('//div[@class="content__list--item"]')
    for item in items:
        # 尝试两种不同的定位方式
        name = item.xpath('.//p[@class="content__list--item--title"]/a/text()')
        if not name:
            name = item.xpath('.//p[contains(@class, "content__list--item--title")]/a/text()')

        if name:
            # 清理文本：移除换行/多余空格，提取小区名称部分
            clean_name = name[0].strip().replace('\n', '')
            # 尝试分割字符串获取小区名（通常是第一个非空格部分）
            parts = clean_name.split()
            if parts:
                names.append(parts[0])
            else:
                names.append(clean_name)
        else:
            names.append("未知小区")
    return names


# 房屋户型
def huxing_info(docs):
    huxings = []
    items = docs.xpath('//div[@class="content__list--item"]')
    for item in items:
        # 使用包含所有信息的文本块
        des_text = item.xpath('.//p[@class="content__list--item--des"]/text()')
        if des_text:
            # 查找包含"室"的文本片段
            for text in des_text:
                if '室' in text:
                    huxings.append(text.strip())
                    break
            else:
                huxings.append("未知户型")
        else:
            huxings.append("未知户型")
    return huxings


# 房屋面积 - 重新编写
def area_info(docs):
    areas = []
    items = docs.xpath('//div[@class="content__list--item"]')

    for item in items:
        # 方法1：尝试直接提取面积文本
        area_text = item.xpath(
            './/p[@class="content__list--item--des"]//text()[contains(., "㎡") or contains(., "平米")]')

        # 方法2：如果直接提取失败，获取整个描述文本
        if not area_text:
            full_text = "".join(item.xpath('.//p[@class="content__list--item--des"]//text()'))
            # 使用正则表达式查找面积
            match = re.search(r'(\d+\.?\d*)\s*(㎡|平米|m²|平方米)', full_text)
            if match:
                areas.append(match.group(1))
                continue

        # 处理提取到的面积文本
        found = False
        for text in area_text:
            # 使用正则表达式提取数字部分
            match = re.search(r'(\d+\.?\d*)', text.strip())
            if match:
                areas.append(match.group(1))
                found = True
                break

        if not found:
            areas.append("0")  # 默认值

    return areas


# 价格
def cost_info(docs):
    costs = []
    items = docs.xpath('//div[@class="content__list--item"]')
    for item in items:
        cost = item.xpath('.//span[@class="content__list--item-price"]/em/text()')
        costs.append(cost[0] if cost else "0")
    return costs


# 翻页点击
def page_click(driver):
    wait = WebDriverWait(driver, 15)
    try:
        # 添加随机滚动
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight * 0.8);")
        time.sleep(random.uniform(0.5, 1.5))

        # 使用更稳定的选择器
        next_btn = wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, 'a.next:not([disabled])'))
        )

        # 模拟人类点击行为
        driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", next_btn)
        time.sleep(random.uniform(1, 2))
        next_btn.click()
        return True
    except Exception as e:
        print(f"翻页失败: {str(e)}")
        return False


# 处理各种弹窗
def handle_popups(driver):
    try:
        # 等待页面稳定
        time.sleep(random.uniform(1.5, 3))

        # 尝试关闭广告弹窗
        popup_selectors = [
            'div.mask-guarantee img.mask-close',  # 广告弹窗
            'div.geetest_panel',  # 极验验证码
            'div.dialog',  # 通用弹窗
            'div.overlay'  # 遮罩层
        ]

        for selector in popup_selectors:
            try:
                element = WebDriverWait(driver, 3).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, selector)))
                if element.is_displayed():
                    driver.execute_script("arguments[0].click();", element)
                    print(f"关闭弹窗: {selector}")
                    time.sleep(1)
            except:
                pass

        # 检查是否有滑块验证
        try:
            slider = driver.find_element(By.CSS_SELECTOR, 'div.geetest_slider_button')
            if slider.is_displayed():
                print("检测到滑块验证，请手动完成验证！")
                input("按回车键继续爬取...")
        except:
            pass

    except Exception as e:
        print(f"弹窗处理异常: {str(e)}")


# 保存数据
def save(quyu_list, name_list, huxing_list, cost_list, area_list):
    house_data = {
        '租房区域': quyu_list,
        '小区名称': name_list,
        '房屋户型': huxing_list,
        '面积(平方米)': area_list,
        '价格(元)': cost_list
    }
    data = pd.DataFrame(house_data)
    # 转换数据类型
    data['面积(平方米)'] = pd.to_numeric(data['面积(平方米)'], errors='coerce').fillna(0)
    data['价格(元)'] = pd.to_numeric(data['价格(元)'], errors='coerce').fillna(0)
    data.to_csv('data/lianjia.csv', encoding='utf-8-sig', index=None)
    print(f"已保存 {len(data)} 条数据")


if __name__ == '__main__':
    # 设置浏览器选项
    options = webdriver.ChromeOptions()
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument(
        'user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')

    # 初始化浏览器
    driver = webdriver.Chrome(options=options)
    driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

    url = 'https://bj.lianjia.com/zufang/'
    driver.get(url)
    driver.maximize_window()  # 最大化窗口

    quyu_list = []
    name_list = []
    area_list = []
    huxing_list = []
    cost_list = []

    # 初始处理弹窗
    handle_popups(driver)

    # 获取总页数
    docs = etree.HTML(driver.page_source)
    num = page_num(docs)
    print(f"总页数: {num}")

    # 爬取每一页
    for i in range(max(num, 5)):  # 测试时限制5页，实际使用改为num
        print(f"正在爬取第 {i + 1}/{num} 页...")

        # 处理当前页弹窗
        handle_popups(driver)

        # 重新解析页面
        docs = etree.HTML(driver.page_source)

        # 获取数据
        quyu_list.extend(quyu_info(docs))
        name_list.extend(name_info(docs))
        area_list.extend(area_info(docs))
        huxing_list.extend(huxing_info(docs))
        cost_list.extend(cost_info(docs))

        print(f"本页获取 {len(quyu_info(docs))} 条数据")

        # 翻页操作
        if i < num - 1:
            if not page_click(driver):
                print("翻页失败，可能遇到验证码，请手动处理")
                input("解决验证后按回车继续...")

            # 随机延迟，避免请求过快
            delay = random.uniform(3, 8)
            print(f"随机延迟 {delay:.1f} 秒...")
            time.sleep(delay)

    # 保存数据
    save(quyu_list, name_list, huxing_list, cost_list, area_list)
    driver.quit()