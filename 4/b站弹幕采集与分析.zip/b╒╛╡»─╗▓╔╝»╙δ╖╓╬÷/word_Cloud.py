from wordcloud import WordCloud
import jieba
import pandas as pd
from _tkinter import _flatten
import matplotlib.pyplot as plt
import numpy as np
def word_cloud():
    comment=pd.read_csv('./data/data.csv')
#分词
    jieba.setLogLevel(jieba.logging.INFO)
    jieba.load_userdict('./word_cloud/hong.txt')
    comment_cut=comment['comment'].apply(jieba.lcut)
#去除停用词

    with open('word_cloud/stoplist.txt',encoding='utf-8') as f:
        stop_words=f.read()
    stop_words+='\n'
    comment_after=comment_cut.apply(lambda x:[i for i in x if i not in stop_words])
# 检查并转换浮点类型图像
#统计
    word_fre=pd.Series(_flatten(list(comment_after))).value_counts()
#绘制词云图
#pic=plt.imread('C:\\Users\\Administrator\\Downloads\\default.jfif')
#处理背景图
    pic=plt.imread('word_cloud/罗小黑.jpg')
# 如果图像是浮点类型且值在0-1之间，转换为0-255的整数
    if np.issubdtype(pic.dtype, np.floating):
        pic = (pic * 255).astype(np.uint8)

# 确保值在0-255范围内
    elif pic.max() > 255:
        pic = (pic / pic.max() * 255).astype(np.uint8)

    word_cloud=WordCloud(mask=pic,background_color="white",font_path= 'C:\Windows\Fonts\simhei.ttf')
    word_cloud.fit_words(word_fre)
    plt.imshow(word_cloud)
    plt.axis("off")
    plt.savefig('word_cloud/词云图.jpg')
    print('词云图保存成功')
    #plt.show()
