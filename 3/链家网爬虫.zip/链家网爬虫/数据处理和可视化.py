import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号

# 读取数据
df = pd.read_csv('data/lianjia.csv', encoding='utf-8')

# 打印原始数据信息
print("原始数据信息:")
print(f"行数: {len(df)}")
print(f"列名: {df.columns.tolist()}")
print(f"前5行数据:\n{df.head()}")


# 数据清理
def clean_data(df):
    # 1. 处理面积异常值
    # 将面积列转换为字符串类型，处理特殊值
    df['面积(平方米)'] = df['面积(平方米)'].astype(str)

    # 处理包含逗号的数值（如"3,000"）
    df['面积(平方米)'] = df['面积(平方米)'].str.replace(',', '')

    # 处理异常值（如"30003500"）
    df['面积(平方米)'] = df['面积(平方米)'].apply(lambda x: x[:4] if len(x) > 5 else x)

    # 转换为数值类型
    df['面积(平方米)'] = pd.to_numeric(df['面积(平方米)'], errors='coerce')

    # 删除面积异常值
    df['面积(平方米)'] = pd.to_numeric(df['面积(平方米)'], errors='coerce')

    # 2. 处理价格异常值
    df = df[df['价格(元)'] > 0]

    # 3. 清理区域和小区名称
    df['租房区域'] = df['租房区域'].replace('暂无区域', '未知区域')
    df['小区名称'] = df['小区名称'].replace('未知小区', '未知')
    df['租房区域'] = df['租房区域'].fillna('未知区域')

    # 4. 清理户型数据
    df['房屋户型'] = df['房屋户型'].replace('未知户型', '未知')

    # 5. 提取户型房间数
    def extract_rooms(layout):
        if isinstance(layout, str):
            match = re.search(r'(\d+)室', layout)
            if match:
                return int(match.group(1))
        return 0  # 默认返回0

    df['房间数'] = df['房屋户型'].apply(extract_rooms)

    # 6. 计算单价
    df['单价(元/平米)'] = df['价格(元)'] / df['面积(平方米)']

    return df


cleaned_df = clean_data(df)

# 打印清理后的数据信息
print("\n清理后数据信息:")
print(f"行数: {len(cleaned_df)}")
if not cleaned_df.empty:
    print(f"区域分布:\n{cleaned_df['租房区域'].value_counts()}")
    print(f"价格统计:\n{cleaned_df['价格(元)'].describe()}")
    print(f"面积统计:\n{cleaned_df['面积(平方米)'].describe()}")


# 数据可视化
def visualize_data(df):
    if df.empty:
        print("警告：数据为空，无法进行可视化")
        return

    # 1. 各区域平均租金
    plt.figure(figsize=(12, 6))

    # 检查是否有足够的区域数据
    if df['租房区域'].nunique() > 1:
        region_avg_price = df.groupby('租房区域')['价格(元)'].mean().sort_values(ascending=False)
        region_avg_price.plot(kind='bar', color='skyblue')
        plt.title('各区域平均租金对比', fontsize=15)
        plt.ylabel('平均租金(元)', fontsize=12)
        plt.xlabel('区域', fontsize=12)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('可视化图表/region_avg_price.png')
        print("已生成各区域平均租金对比图")
    else:
        print("区域数据不足，跳过区域平均租金对比图")

    # 2. 面积与租金关系
    plt.figure(figsize=(10, 6))
    sns.scatterplot(x='面积(平方米)', y='价格(元)', data=df, alpha=0.6, color='green')
    plt.title('房屋面积与租金关系', fontsize=15)
    plt.xlabel('面积(平方米)', fontsize=12)
    plt.ylabel('租金(元)', fontsize=12)
    plt.tight_layout()
    plt.savefig('可视化图表/area_price_scatter.png')
    print("已生成房屋面积与租金关系图")

    # 3. 户型分布
    plt.figure(figsize=(10, 6))
    room_counts = df['房间数'].value_counts().sort_index()
    room_counts = room_counts[room_counts.index > 0]  # 只显示有房间数的户型

    if not room_counts.empty:
        room_counts.plot(kind='bar', color='orange')
        plt.title('户型房间数分布', fontsize=15)
        plt.xlabel('房间数', fontsize=12)
        plt.ylabel('房源数量', fontsize=12)
        plt.xticks(rotation=0)
        plt.tight_layout()
        plt.savefig('可视化图表/room_distribution.png')
        print("已生成户型房间数分布图")
    else:
        print("房间数数据不足，跳过户型分布图")

    # 4. 租金分布直方图
    plt.figure(figsize=(10, 6))
    sns.histplot(df['价格(元)'], bins=50, kde=True, color='purple')
    plt.title('租金分布直方图', fontsize=15)
    plt.xlabel('租金(元)', fontsize=12)
    plt.ylabel('房源数量', fontsize=12)

    # 设置合理的显示范围
    if df['价格(元)'].max() > 20000:
        plt.xlim(0, 20000)

    plt.tight_layout()
    plt.savefig('可视化图表/price_histogram.png')
    print("已生成租金分布直方图")

    # 5. 区域房源数量
    plt.figure(figsize=(12, 6))

    # 检查是否有足够的区域数据
    if df['租房区域'].nunique() > 1:
        region_counts = df['租房区域'].value_counts().sort_values(ascending=False)
        region_counts.plot(kind='bar', color='teal')
        plt.title('各区域房源数量', fontsize=15)
        plt.ylabel('房源数量', fontsize=12)
        plt.xlabel('区域', fontsize=12)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('可视化图表/region_counts.png')
        print("已生成各区域房源数量图")
    else:
        print("区域数据不足，跳过区域房源数量图")


# 执行可视化
visualize_data(cleaned_df)

print("\n数据处理和可视化完成！")